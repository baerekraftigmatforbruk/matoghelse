PhoneResponsive={"785":{
"pageLayer":{"w":785,"h":500,"bgColor":"#ffffff","bgImage":"images/byggåker_bakgrunn_6.jpg","bgSize":"785px 515px","bgRepeat":"no-repeat"}
,
"button34081":{"x":646,"y":469,"w":71.000000,"h":33.000000,"stylemods":[{"sel":"div.button34081Text","decl":" { position:fixed; left:6px; top:5px; width:61px; height:25px;}"},{"sel":"span.button34081Text","decl":" { display:table-cell; position:relative; width:61px; height:25px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#333333;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAsCAYAAAD2BO8qAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEgSURBVGhD7dPhacMwEIZh79N/Nt6io3SQDNI9W73iTihSDE0JxS7vA6In31nBX+1FkiRJkiTpX1nX9X3btq+jFTO3Un88qLn3k/pZnPHbe08vQ43tQwb5Awb5IkdBDuFNQbLnPhZ9esjzulXvA3VZNch939/oM1+bRfzOdOYl5IPHtomHOgqyBZCBZL83ns1MWTVIrucZ6H8DzPX90xsfNvUPNtTM332e9FnUESxvbHsr61BR6hpkrLvg41q7J9b0zzmtCOZlQdLLOt9WanBG9scz2NOP7fVEMM8GOX3auafOWf6yp0bsa4BxZgszZzkvLl1LBhPbJh70KMh8q6ZPMM9j5Sw1PebY18EielOY3WrnSpIkSZIkSZIkSdJfWZZvFvzRatOsMgcAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAsCAYAAAD2BO8qAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEgSURBVGhD7dPhacMwEIZh79N/Nt6io3SQDNI9W73iTihSDE0JxS7vA6In31nBX+1FkiRJkiTpX1nX9X3btq+jFTO3Un88qLn3k/pZnPHbe08vQ43tQwb5Awb5IkdBDuFNQbLnPhZ9esjzulXvA3VZNch939/oM1+bRfzOdOYl5IPHtomHOgqyBZCBZL83ns1MWTVIrucZ6H8DzPX90xsfNvUPNtTM332e9FnUESxvbHsr61BR6hpkrLvg41q7J9b0zzmtCOZlQdLLOt9WanBG9scz2NOP7fVEMM8GOX3auafOWf6yp0bsa4BxZgszZzkvLl1LBhPbJh70KMh8q6ZPMM9j5Sw1PebY18EielOY3WrnSpIkSZIkSZIkSdJfWZZvFvzRatOsMgcAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAtCAYAAADSmlexAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEgSURBVGhD7dNRboMwEEVR9pM/ELvoUrqQLKT7bHytGcvYQWqqfBT1HsnqmBkc8QqLJEmSJEnSv7eu68e2bd9nK2bupf58UnPvF/WrOOO3915CBhvbpwzzhwzzjc7CHAKcwmTPfSz69JDndaveB+qyapj7vt/oM1+bRfzOdOZl5MPHtokHOwuzhZChZL83ns1MWTVMrucZ6H8DzPX9SxgfOPUPN9TMHz5V+izqCJc3t72ddagodQ0z1iH8uNbuiTX9g/60COdtYdLLOt9aanBG9scz2NOP7TVFOK+GOX3muafOWf6yp0bsa4hxZgs0ZzkvLl1PhhPbJh72LMx8u6bPMc9j5Sw1PebY18EielOg3WrnSpIkSZIkSZIkSZJ0sCwP4BjRajo7PvIAAAAASUVORK5CYII=" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAsCAYAAAD2BO8qAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEgSURBVGhD7dPhacMwEIZh79N/Nt6io3SQDNI9W73iTihSDE0JxS7vA6In31nBX+1FkiRJkiTpX1nX9X3btq+jFTO3Un88qLn3k/pZnPHbe08vQ43tQwb5Awb5IkdBDuFNQbLnPhZ9esjzulXvA3VZNch939/oM1+bRfzOdOYl5IPHtomHOgqyBZCBZL83ns1MWTVIrucZ6H8DzPX90xsfNvUPNtTM332e9FnUESxvbHsr61BR6hpkrLvg41q7J9b0zzmtCOZlQdLLOt9WanBG9scz2NOP7fVEMM8GOX3auafOWf6yp0bsa4BxZgszZzkvLl1LBhPbJh70KMh8q6ZPMM9j5Sw1PebY18EielOY3WrnSpIkSZIkSZIkSdJfWZZvFvzRatOsMgcAAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 9.000000 2.000000 L 62.000000 2.000000 L 64.750000 2.562500 L 66.937500 4.062500 L 68.437500 6.312500 L 69.000000 9.000000 L 69.000000 24.000000 L 68.437500 26.750000 L 66.937500 28.937500 L 64.750000 30.437500 L 62.000000 31.000000 L 9.000000 31.000000 L 6.375000 30.500000 L 4.062500 29.000000 L 2.562500 26.687500 L 2.000000 24.000000 L 2.000000 9.000000 L 2.562500 6.312500 L 4.062500 4.062500 L 6.312500 2.562500 L 9.000000 2.000000 z"}
,
"button109928":{"x":12,"y":-129,"w":48.000000,"h":32.000000,"stylemods":[{"sel":"div.button109928Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button109928Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_cancel_normal.png" ,"fdO": "images/std_qt_cancel_over.png" ,"fdD": "images/std_qt_cancel_clicked.png" ,"fdDi": "images/std_qt_cancel_normal.png" ,"p": "M 0.000000 0.000000 L 47.000000 0.000000 L 47.000000 31.000000 L 0.000000 31.000000 L 0.000000 0.000000 z"}
,
"button109934":{"x":397,"y":-141,"w":48.000000,"h":32.000000,"stylemods":[{"sel":"div.button109934Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button109934Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_back_normal.png" ,"fdO": "images/std_qt_back_over.png" ,"fdD": "images/std_qt_back_clicked.png" ,"fdDi": "images/std_qt_back_normal.png" ,"p": "M 0.000000 0.000000 L 47.000000 0.000000 L 47.000000 31.000000 L 0.000000 31.000000 L 0.000000 0.000000 z"}
,
"button109940":{"x":452,"y":-138,"w":48.000000,"h":32.000000,"stylemods":[{"sel":"div.button109940Text","decl":" { position:fixed; left:2px; top:2px; width:43px; height:27px;}"},{"sel":"span.button109940Text","decl":" { display:table-cell; position:relative; width:43px; height:27px; vertical-align:middle; text-align:center; line-height:11px; font-size:11px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAcSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAAMCZGhggAAHiS368AAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_next_normal.png" ,"fdO": "images/std_qt_next_over.png" ,"fdD": "images/std_qt_next_clicked.png" ,"fdDi": "images/std_qt_next_normal.png" ,"p": "M 0.000000 0.000000 L 47.000000 0.000000 L 47.000000 31.000000 L 0.000000 31.000000 L 0.000000 0.000000 z"}
,
"shape24511":{"x":598,"y":467,"w":43.000000,"h":33.000000,"stylemods":[{"sel":"div.shape24511Text","decl":" { position:fixed; left:5px; top:5px; width:38px; height:27px;}"},{"sel":"span.shape24511Text","decl":" { display:table-cell; position:relative; width:38px; height:27px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAsCAYAAAAuCEsgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAD3aiVMAAEhazUbAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 41.000000 9.335000 L 14.000000 9.335000 L 14.000000 2.000000 L 2.000000 16.000000 L 14.000000 31.000000 L 14.000000 22.665001 L 41.000000 22.665001 L 41.000000 9.335000 z"}
,
"shape24538":{"x":723,"y":467,"w":43.000000,"h":33.000000,"stylemods":[{"sel":"div.shape24538Text","decl":" { position:fixed; left:5px; top:5px; width:38px; height:27px;}"},{"sel":"span.shape24538Text","decl":" { display:table-cell; position:relative; width:38px; height:27px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAAsCAYAAAAuCEsgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAfSURBVGhD7cEBAQAAAIIg/69uSEAAAAAAAAAAAAD3aiVMAAEhazUbAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 41.000000 9.335000 L 14.000000 9.335000 L 14.000000 2.000000 L 2.000000 16.000000 L 14.000000 31.000000 L 14.000000 22.665001 L 41.000000 22.665001 L 41.000000 9.335000 z"}
,
"shape24578":{"x":726,"y":49,"w":28.000000,"h":30.000000,"stylemods":[{"sel":"div.shape24578Text","decl":" { position:fixed; left:5px; top:5px; width:22px; height:24px;}"},{"sel":"span.shape24578Text","decl":" { display:table-cell; position:relative; width:22px; height:24px; vertical-align:middle; text-align:center; line-height:27px; font-size:27px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAeCAYAAAA/xX6fAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cGBAAAAAMOg+VMf4QJVAAAAXDUNPgAB+U854AAAAABJRU5ErkJggg=="  ,"fd": "images/byggåker_bakgrunn_grønn2.jpg" ,"p": "M 2.000000 2.000000 L 26.000000 2.000000 L 26.000000 28.000000 L 2.000000 28.000000 L 2.000000 2.000000 z" ,"i":"images/byggåker_bakgrunn_grønn2.jpg"}
,
"shape24575":{"x":716,"y":21,"w":49.000000,"h":31.000000,"stylemods":[{"sel":"div.shape24575Text","decl":" { position:fixed; left:5px; top:5px; width:43px; height:25px;}"},{"sel":"span.shape24575Text","decl":" { display:table-cell; position:relative; width:43px; height:25px; vertical-align:middle; text-align:center; line-height:28px; font-size:28px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAAfCAYAAABOOiVaAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAdSURBVFhH7cEBDQAAAMKg909tDjcgAAAAAADgRw0X2wABvoIwHgAAAABJRU5ErkJggg=="  ,"fd": "images/byggåker_bakgrunn_grønn2.jpg" ,"p": "M 24.000000 2.000000 L 47.000000 29.000000 L 2.000000 29.000000 L 24.000000 2.000000 z" ,"i":"images/byggåker_bakgrunn_grønn2.jpg"}
,
"progress114037":{"x":22,"y":484,"w":156,"h":16,"bOffBottom":0,"vert":0,"barImage":"images/PhoneLandscape_progress114037_bar.png","bgImage":"images/PhoneLandscape_progress114037.png"}
,
"shape112366":{"x":46,"y":46,"w":645.000000,"h":392.000000,"stylemods":[{"sel":"div.shape112366Text","decl":" { position:fixed; left:3px; top:3px; width:639px; height:386px;}"},{"sel":"span.shape112366Text","decl":" { display:table-cell; position:relative; width:639px; height:386px; vertical-align:middle; text-align:center; line-height:14px; font-size:14px; font-family:\"Arial\"; color:#333333;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAoUAAAGICAYAAAA3X5qXAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAPsSURBVHhe7cExAQAAAMKg9U9tDQ8gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAO1ABxCQABkK3PqQAAAABJRU5ErkJggg=="  ,"fd": "" ,"p": "M 1.000000 1.000000 L 644.000000 1.000000 L 644.000000 391.000000 L 1.000000 391.000000 L 1.000000 1.000000 z"}
,
"image114140":{"x":443,"y":110,"w":216,"h":131,"bOffBottom":0,"i":"images/hummer.png"}
,
"text112484":{"x":70,"y":61,"w":124,"h":28,"txtscale":100,"bOffBottom":0}
,
"text112384":{"x":70,"y":86,"w":273,"h":42,"txtscale":100,"bOffBottom":0}
,
"text112385":{"x":91,"y":121,"w":36,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112386":{"x":67,"y":120,"fsize":16,"bOffBottom":0}
,
"text112387":{"x":91,"y":156,"w":40,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112388":{"x":67,"y":155,"fsize":16,"bOffBottom":0}
,
"text112389":{"x":91,"y":191,"w":58,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112390":{"x":67,"y":190,"fsize":16,"bOffBottom":0}
,
"text112391":{"x":91,"y":226,"w":51,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112392":{"x":67,"y":225,"fsize":16,"bOffBottom":0}
,
"text112393":{"x":233,"y":119,"w":36,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112394":{"x":209,"y":120,"fsize":16,"bOffBottom":0}
,
"text112395":{"x":233,"y":156,"w":71,"h":23,"txtscale":100,"bOffBottom":0}
,
"check112396":{"x":209,"y":155,"fsize":16,"bOffBottom":0}
,
"text112397":{"x":233,"y":191,"w":50,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112398":{"x":209,"y":190,"fsize":16,"bOffBottom":0}
,
"text112510":{"x":233,"y":226,"w":87,"h":29,"txtscale":100,"bOffBottom":0}
,
"check112511":{"x":209,"y":225,"fsize":16,"bOffBottom":0}
,
"text112838":{"x":103,"y":289,"w":124,"h":25,"txtscale":100,"bOffBottom":0}
,
"text112784":{"x":103,"y":315,"w":567,"h":29,"txtscale":100,"bOffBottom":0}
,
"text112785":{"x":122,"y":338,"w":33,"h":29,"txtscale":100,"bOffBottom":0}
,
"radio112786":{"x":98,"y":337,"fsize":16,"bOffBottom":0}
,
"text112787":{"x":122,"y":373,"w":33,"h":29,"txtscale":100,"bOffBottom":0}
,
"radio112788":{"x":98,"y":372,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
qu112382.reorgChoice();}
,
"RCDResultResize":function(){}
,"preload":['images/byggåker_bakgrunn_6.jpg','images/PhoneLandscape_progress114037.png','images/PhoneLandscape_progress114037_bar.png']
},
"480":{
"pageLayer":{"w":480,"h":763,"bgColor":"#ffffff","bgImage":"images/byggåker_bakgrunn_6.jpg","bgSize":"480px 315px","bgRepeat":"no-repeat"}
,
"button34081":{"x":394,"y":603,"w":45.000000,"h":22.000000,"stylemods":[{"sel":"div.button34081Text","decl":" { position:fixed; left:6px; top:5px; width:35px; height:14px;}"},{"sel":"span.button34081Text","decl":" { display:table-cell; position:relative; width:35px; height:14px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#333333;}"}],"bOffBottom":0  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAAhCAYAAACMX2hNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACoSURBVFhH7ZTdCcMwDAa9T99ivEVH8SAdpHu2vmIZB0qTN0NzB0KyfkAfCkkiIiJycbZte+ScX7O13J181PEt/8T/4kzPMtpytZRy68/B3wr8dsFunwv3XFy9Rg+emeghnmeWwZJHAqMeQoDc3EMcYvBzDb+MMwLx9ESMb8Z1Rk+zGnUEUg8jtwwWOxDIkuMT7UJ3OeI+s/tJRR9vEREREREREbk2Kb0BJOhhRsHuVaoAAAAASUVORK5CYII=" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAAhCAYAAACMX2hNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACoSURBVFhH7ZTdCcMwDAa9T99ivEVH8SAdpHu2vmIZB0qTN0NzB0KyfkAfCkkiIiJycbZte+ScX7O13J181PEt/8T/4kzPMtpytZRy68/B3wr8dsFunwv3XFy9Rg+emeghnmeWwZJHAqMeQoDc3EMcYvBzDb+MMwLx9ESMb8Z1Rk+zGnUEUg8jtwwWOxDIkuMT7UJ3OeI+s/tJRR9vEREREREREbk2Kb0BJOhhRsHuVaoAAAAASUVORK5CYII=" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADkAAAAiCAYAAADlCXHdAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACpSURBVFhH7dTRCQMhDIBh9+nbiVt0lBvkBumerX8x4kGp1yeh/B+EeDGCwdIkSZI0tW3bkXN+jlFrd+qxT671B/mbKz1L1QvupZRb++z+eshPL9ni/dKtFq+/Rw+ZM9HDejyzFBedDRn7MQyojT2sYyDyuEde6sqQZHpiTa7BK/WeGnvsMyT7EdSW4nKTIblo/7m2YU811u3M6Y8r+viWJEmSJEnSD1J6ASxHYUZ6jVO2AAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAAhCAYAAACMX2hNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACoSURBVFhH7ZTdCcMwDAa9T99ivEVH8SAdpHu2vmIZB0qTN0NzB0KyfkAfCkkiIiJycbZte+ScX7O13J181PEt/8T/4kzPMtpytZRy68/B3wr8dsFunwv3XFy9Rg+emeghnmeWwZJHAqMeQoDc3EMcYvBzDb+MMwLx9ESMb8Z1Rk+zGnUEUg8jtwwWOxDIkuMT7UJ3OeI+s/tJRR9vEREREREREbk2Kb0BJOhhRsHuVaoAAAAASUVORK5CYII="  ,"fd": "" ,"fdO": "" ,"fdD": "" ,"fdDi": "" ,"p": "M 6.000000 2.000000 L 39.000000 2.000000 L 40.562500 2.312500 L 41.875000 3.187500 L 42.687500 4.437500 L 43.000000 6.000000 L 43.000000 16.000000 L 42.687500 17.562500 L 41.875000 18.875000 L 40.562500 19.687500 L 39.000000 20.000000 L 6.000000 20.000000 L 4.500000 19.750000 L 3.187500 18.875000 L 2.312500 17.562500 L 2.000000 16.000000 L 2.000000 6.000000 L 2.312500 4.437500 L 3.187500 3.187500 L 4.437500 2.312500 L 6.000000 2.000000 z"}
,
"button109928":{"x":8,"y":379,"w":30.000000,"h":20.000000,"stylemods":[{"sel":"div.button109928Text","decl":" { position:fixed; left:2px; top:2px; width:25px; height:15px;}"},{"sel":"span.button109928Text","decl":" { display:table-cell; position:relative; width:25px; height:15px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_cancel_normal.png" ,"fdO": "images/std_qt_cancel_over.png" ,"fdD": "images/std_qt_cancel_clicked.png" ,"fdDi": "images/std_qt_cancel_normal.png" ,"p": "M 0.000000 0.000000 L 29.000000 0.000000 L 29.000000 19.000000 L 0.000000 19.000000 L 0.000000 0.000000 z"}
,
"button109934":{"x":243,"y":371,"w":30.000000,"h":20.000000,"stylemods":[{"sel":"div.button109934Text","decl":" { position:fixed; left:2px; top:2px; width:25px; height:15px;}"},{"sel":"span.button109934Text","decl":" { display:table-cell; position:relative; width:25px; height:15px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_back_normal.png" ,"fdO": "images/std_qt_back_over.png" ,"fdD": "images/std_qt_back_clicked.png" ,"fdDi": "images/std_qt_back_normal.png" ,"p": "M 0.000000 0.000000 L 29.000000 0.000000 L 29.000000 19.000000 L 0.000000 19.000000 L 0.000000 0.000000 z"}
,
"button109940":{"x":276,"y":373,"w":30.000000,"h":20.000000,"stylemods":[{"sel":"div.button109940Text","decl":" { position:fixed; left:2px; top:2px; width:25px; height:15px;}"},{"sel":"span.button109940Text","decl":" { display:table-cell; position:relative; width:25px; height:15px; vertical-align:middle; text-align:center; line-height:7px; font-size:7px; font-family:\"Lucida Sans Unicode\"; color:#ffffff;}"}],"bOffBottom":1  ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdO": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdD": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC" ,"tdDi": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAUCAYAAACaq43EAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAZSURBVEhL7cExAQAAAMKg9U9tCj8gAADOagl0AAHhlMiiAAAAAElFTkSuQmCC"  ,"fd": "images/std_qt_next_normal.png" ,"fdO": "images/std_qt_next_over.png" ,"fdD": "images/std_qt_next_clicked.png" ,"fdDi": "images/std_qt_next_normal.png" ,"p": "M 0.000000 0.000000 L 29.000000 0.000000 L 29.000000 19.000000 L 0.000000 19.000000 L 0.000000 0.000000 z"}
,
"shape24511":{"x":365,"y":600,"w":27.000000,"h":21.000000,"stylemods":[{"sel":"div.shape24511Text","decl":" { position:fixed; left:5px; top:5px; width:22px; height:15px;}"},{"sel":"span.shape24511Text","decl":" { display:table-cell; position:relative; width:22px; height:15px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAgCAYAAAB+ZAqzAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAcKsGEyAAAZSQqAsAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 25.000000 5.915000 L 8.000000 5.915000 L 8.000000 2.000000 L 2.000000 10.000000 L 8.000000 19.000000 L 8.000000 14.085000 L 25.000000 14.085000 L 25.000000 5.915000 z"}
,
"shape24538":{"x":442,"y":601,"w":27.000000,"h":21.000000,"stylemods":[{"sel":"div.shape24538Text","decl":" { position:fixed; left:5px; top:5px; width:22px; height:15px;}"},{"sel":"span.shape24538Text","decl":" { display:table-cell; position:relative; width:22px; height:15px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAgCAYAAAB+ZAqzAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAbSURBVFhH7cEBAQAAAIIg/69uSEAAAAAAcKsGEyAAAZSQqAsAAAAASUVORK5CYII="  ,"fd": "" ,"p": "M 25.000000 5.915000 L 8.000000 5.915000 L 8.000000 2.000000 L 2.000000 10.000000 L 8.000000 19.000000 L 8.000000 14.085000 L 25.000000 14.085000 L 25.000000 5.915000 z"}
,
"shape24578":{"x":443,"y":63,"w":18.000000,"h":19.000000,"stylemods":[{"sel":"div.shape24578Text","decl":" { position:fixed; left:5px; top:5px; width:12px; height:13px;}"},{"sel":"span.shape24578Text","decl":" { display:table-cell; position:relative; width:12px; height:13px; vertical-align:middle; text-align:center; line-height:16px; font-size:16px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAVSURBVDhPYxgFo2AUjIJRQFvAwAAABWsAAQxNSHUAAAAASUVORK5CYII="  ,"fd": "images/byggåker_bakgrunn_grønn2.jpg" ,"p": "M 2.000000 2.000000 L 16.000000 2.000000 L 16.000000 17.000000 L 2.000000 17.000000 L 2.000000 2.000000 z" ,"i":"images/byggåker_bakgrunn_grønn2.jpg"}
,
"shape24575":{"x":437,"y":27,"w":31.000000,"h":20.000000,"stylemods":[{"sel":"div.shape24575Text","decl":" { position:fixed; left:5px; top:5px; width:25px; height:14px;}"},{"sel":"span.shape24575Text","decl":" { display:table-cell; position:relative; width:25px; height:14px; vertical-align:middle; text-align:center; line-height:17px; font-size:17px; font-family:\"Arial\"; color:#ffffff;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAUCAYAAAB1aeb6AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAaSURBVEhL7cEBDQAAAMKg909tDjcgAADO1AAJxAABoSRQGwAAAABJRU5ErkJggg=="  ,"fd": "images/byggåker_bakgrunn_grønn2.jpg" ,"p": "M 15.000000 2.000000 L 29.000000 18.000000 L 2.000000 18.000000 L 15.000000 2.000000 z" ,"i":"images/byggåker_bakgrunn_grønn2.jpg"}
,
"progress114037":{"x":13,"y":622,"w":95,"h":10,"bOffBottom":0,"vert":0,"barImage":"images/PhonePortrait_progress114037_bar.png","bgImage":"images/PhonePortrait_progress114037.png"}
,
"shape112366":{"x":28,"y":59,"w":395.000000,"h":240.000000,"stylemods":[{"sel":"div.shape112366Text","decl":" { position:fixed; left:3px; top:3px; width:389px; height:234px;}"},{"sel":"span.shape112366Text","decl":" { display:table-cell; position:relative; width:389px; height:234px; vertical-align:middle; text-align:center; line-height:8px; font-size:8px; font-family:\"Arial\"; color:#333333;}"}],"bOffBottom":0 ,"td": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAYsAAADwCAYAAADxckg9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAGHSURBVHhe7cEBDQAAAMKg909tDjcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALhTA8p7AAHp4CzRAAAAAElFTkSuQmCC"  ,"fd": "" ,"p": "M 1.000000 1.000000 L 394.000000 1.000000 L 394.000000 239.000000 L 1.000000 239.000000 L 1.000000 1.000000 z"}
,
"image114140":{"x":271,"y":141,"w":132,"h":80,"bOffBottom":0,"i":"images/hummer.png"}
,
"text112484":{"x":43,"y":78,"w":76,"h":42,"txtscale":100,"bOffBottom":0}
,
"text112384":{"x":66,"y":95,"w":347,"h":37,"txtscale":100,"bOffBottom":0}
,
"text112385":{"x":93,"y":140,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112386":{"x":63,"y":139,"fsize":16,"bOffBottom":0}
,
"text112387":{"x":93,"y":185,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112388":{"x":63,"y":184,"fsize":16,"bOffBottom":0}
,
"text112389":{"x":93,"y":230,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112390":{"x":63,"y":229,"fsize":16,"bOffBottom":0}
,
"text112391":{"x":93,"y":275,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112392":{"x":63,"y":274,"fsize":16,"bOffBottom":0}
,
"text112393":{"x":93,"y":320,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112394":{"x":63,"y":319,"fsize":16,"bOffBottom":0}
,
"text112395":{"x":93,"y":365,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112396":{"x":63,"y":364,"fsize":16,"bOffBottom":0}
,
"text112397":{"x":93,"y":410,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112398":{"x":63,"y":409,"fsize":16,"bOffBottom":0}
,
"text112510":{"x":66,"y":455,"w":347,"h":37,"txtscale":100,"bOffBottom":0}
,
"check112511":{"x":36,"y":454,"fsize":16,"bOffBottom":0}
,
"text112838":{"x":63,"y":371,"w":76,"h":42,"txtscale":100,"bOffBottom":0}
,
"text112784":{"x":66,"y":95,"w":347,"h":42,"txtscale":100,"bOffBottom":0}
,
"text112785":{"x":93,"y":140,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"radio112786":{"x":63,"y":139,"fsize":16,"bOffBottom":0}
,
"text112787":{"x":93,"y":185,"w":320,"h":37,"txtscale":100,"bOffBottom":0}
,
"radio112788":{"x":63,"y":184,"fsize":16,"bOffBottom":0}
,
"RCDResetQuestion":function(){
try{if(window.dragMgr)window.dragMgr.clearDropZones();}catch(e){if(e&&e.message)console.log(e.message);}
qu112382.reorgChoice();}
,
"RCDResultResize":function(){}
,"preload":['images/byggåker_bakgrunn_6.jpg','images/PhonePortrait_progress114037.png','images/PhonePortrait_progress114037_bar.png']
}}
